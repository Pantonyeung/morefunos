# GOOGLE SHEET SPEC｜More Fun OS

此資料夾存放 Google Sheet 作為後台 CMS 的欄位規格。

## Purpose

Google Sheet 用作：

- 商品資料
- 價格
- 分類
- 圖片 URL
- 售罄狀態
- 推薦排序
- 首頁內容
- 飲品升級
- 套餐選項

## Planned Files

- SHEET_STRUCTURE.md
- PRODUCTS_TABLE.md
- OPTIONS_TABLE.md
- SOLD_OUT_RULES.md
- IMAGE_CDN_RULES.md
- ADMIN_USAGE.md

## Principle

Google Sheet 欄位要簡單、穩定、容易由店主修改。

不應設計成大型 ERP。
