# TASK QUEUE｜More Fun OS

## Current Phase

Foundation Phase

## Task Order

### TASK 001｜Project Setup

Goal：建立前端專案基礎結構。

Expected：

- Next.js / React project
- Mobile first layout
- Tailwind CSS
- Basic routing
- Placeholder pages

### TASK 002｜Google Sheet Data Contract

Goal：定義 Google Sheet 欄位與資料讀取方式。

Expected：

- Product schema
- Option schema
- Category schema
- Sold-out field
- Image URL field

### TASK 003｜Menu Page

Goal：建立手機點單頁。

Expected：

- Category navigation
- Product cards
- Hot items
- More button
- Sold-out display

### TASK 004｜Product Detail

Goal：建立商品詳情與套餐選項。

Expected：

- Riceball selection
- Drink upgrade
- Snack options
- Remarks
- Quantity control

### TASK 005｜Cart / Memory Jar

Goal：建立購物車／記憶罐。

Expected：

- Selected item count
- Item detail
- Add/remove quantity
- Checkout CTA

### TASK 006｜WhatsApp Order

Goal：生成清楚的 WhatsApp 訂單摘要。

Expected：

- Pickup time on top
- Product lines
- Options
- Remarks
- Total price

### TASK 007｜Simple Admin

Goal：建立簡易後台入口。

Expected：

- Login gate
- Sold-out control
- Product search
- Daily reset rule documented
