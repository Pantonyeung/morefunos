# CODEX WORKSPACE｜More Fun OS

此資料夾存放交給 Codex 的任務文件。

## Purpose

每次交給 Codex 的工作，應該整理成明確任務：

- 要做什麼
- 不做什麼
- 參考哪些文件
- 修改哪些範圍
- 驗收標準是什麼

## Planned Files

- TASK_001_PROJECT_SETUP.md
- TASK_002_GOOGLE_SHEET_DATA.md
- TASK_003_MENU_PAGE.md
- TASK_004_PRODUCT_DETAIL.md
- TASK_005_CART_CHECKOUT.md
- TASK_006_WHATSAPP_ORDER.md
- TASK_007_ADMIN_SOLD_OUT.md

## Rule

一次只給 Codex 一個清晰任務。

不要一次叫 Codex 完成整個系統，否則容易失控。
