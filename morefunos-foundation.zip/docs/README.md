# docs｜More Fun OS Documentation

此資料夾存放所有可交付給 Codex 的正式規格。

## Folder Map

```text
docs/
├── ui/
├── google-sheet/
├── business-rules/
└── codex/
```

## Rule

文件先行，程式碼後行。

任何 UI、業務邏輯、Google Sheet 欄位、WhatsApp 格式，一律先在 docs 內記錄，再交 Codex 實作。
