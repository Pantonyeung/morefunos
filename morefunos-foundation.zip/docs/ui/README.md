# UI SPEC｜More Fun OS

此資料夾存放手機點餐網站 UI 規格。

## UI Direction

- Mobile First
- 輕日系現代簡約
- 清晰、快、少干擾
- 以成交與完成下單為核心
- 適合單手操作
- 底部導航與結帳區需要穩定

## Planned Files

- UI_01_GLOBAL_LAYOUT.md
- UI_02_NAVIGATION.md
- UI_03_MENU_PAGE.md
- UI_04_PRODUCT_CARD.md
- UI_05_PRODUCT_DETAIL.md
- UI_06_CART_MEMORY_JAR.md
- UI_07_CHECKOUT.md
- UI_08_MEMBER_MEMORY_SEED.md

## Status

Waiting for locked UI files.
