# BUSINESS RULES｜More Fun OS

此資料夾存放磨飯點餐系統的正式業務規則。

## Scope

- 商品分類
- 套餐邏輯
- 飯團價格層
- 飲品升級
- 小食選項
- 沙律選項
- 售罄規則
- WhatsApp 出單格式
- 記憶種子
- 取餐時間
- 備註欄

## Planned Files

- ORDERING_RULES.md
- COMBO_RULES.md
- DRINK_UPGRADE_RULES.md
- RICEBALL_RULES.md
- SALAD_RULES.md
- SNACK_RULES.md
- WHATSAPP_ORDER_FORMAT.md
- MEMORY_SEED_RULES.md

## Principle

業務規則要先鎖定，再實作。

Codex 不可以自行推測餐牌、價格或套餐邏輯。
