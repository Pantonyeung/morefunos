# CODEX TASK 001｜Full Repository Audit

Copy this task into Codex after the repository is connected.

## Task

Perform a full repository audit for `Pantonyeung/morefunos`.

This is a review task first. Do not build the full website yet.

## Goals

1. Read all existing files in the repository.
2. Understand the project direction from:
   - `README.md`
   - `PROJECT_BRIEF.md`
   - `CODEX_INSTRUCTIONS.md`
   - `AGENTS.md`
   - all files under `docs/`
3. Create a file index.
4. Create a repo audit report.
5. Identify missing files and next build tasks.

## Required Output Files

Create these files if they do not already exist:

```text
docs/codex/FILE_INDEX.md
docs/codex/REPO_AUDIT_001.md
docs/codex/NEXT_TASKS.md
```

## FILE_INDEX.md Must Include

- All files found
- Purpose of each file
- Whether each file is complete, draft, or missing content
- Which files Codex should read first

## REPO_AUDIT_001.md Must Include

- Current repository status
- What is ready
- What is missing
- Any conflicting rules
- Any unclear instructions
- P0 blockers
- P1 important improvements
- Recommended next step

## NEXT_TASKS.md Must Include

A clear ordered task list:

1. Project setup
2. Google Sheet data contract
3. Menu page
4. Product detail page
5. Cart / Memory Jar
6. Checkout
7. WhatsApp order format
8. Simple admin / sold-out control

## Restrictions

- Do not add online payment.
- Do not add delivery.
- Do not add POS API integration.
- Do not add complex member redemption.
- Do not add inventory / warehouse features.
- Do not redesign the brand direction.
- Do not guess missing menu prices.

## Commit

Commit the audit files when finished.

## Final Response

Report:

- Files created
- Key risks found
- Whether the repository is ready for first build
- Exact next Codex task to run
