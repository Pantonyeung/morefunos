# ChatGPT Review Request

After Codex completes the audit, send this to ChatGPT together with the GitHub repo or PR link.

## Message to ChatGPT

Please review my GitHub repository:

https://github.com/Pantonyeung/morefunos

Focus on:

1. `docs/codex/FILE_INDEX.md`
2. `docs/codex/REPO_AUDIT_001.md`
3. `docs/codex/NEXT_TASKS.md`
4. `README.md`
5. `PROJECT_BRIEF.md`
6. `CODEX_INSTRUCTIONS.md`
7. `AGENTS.md`

Check whether Codex understood the More Fun / 磨飯 project correctly.

Please identify:

- Wrong assumptions
- Missing business rules
- Missing UI rules
- Missing Google Sheet rules
- Any part that may cause Codex to build the wrong website
- The next single task I should give to Codex

Return a direct action list.
