# More Fun OS｜ChatGPT + GitHub + Codex Workflow

## Correct Workflow

GitHub is the shared source of truth.

ChatGPT reviews and writes precise instructions.  
Codex edits, tests, commits, and creates pull requests.  
GitHub stores every file.

## Step 1｜Put Files Into GitHub

Upload the foundation files to:

https://github.com/Pantonyeung/morefunos

The repository should include:

- `README.md`
- `PROJECT_BRIEF.md`
- `CODEX_INSTRUCTIONS.md`
- `AGENTS.md`
- `docs/`

## Step 2｜Connect Codex to GitHub

Open Codex inside ChatGPT.

Select repository:

`Pantonyeung/morefunos`

## Step 3｜Run Audit First

Give Codex:

`CODEX_TASK_001_REPO_AUDIT.md`

Do not ask Codex to build the full website yet.

## Step 4｜Return to ChatGPT

After Codex creates audit files or a PR, send the GitHub link back to ChatGPT.

ChatGPT will check:

- Whether Codex understood correctly
- Whether files are missing
- Whether business rules are wrong
- Whether next task is safe

## Step 5｜Only Then Start Building

Build one task at a time.

Recommended order:

1. Project setup
2. Google Sheet schema
3. Menu page
4. Product detail page
5. Cart / Memory Jar
6. Checkout
7. WhatsApp order
8. Admin sold-out control
