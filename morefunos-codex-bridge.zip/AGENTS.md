# AGENTS.md｜More Fun OS Codex Rules

## Project

This repository is for More Fun / 磨飯 mobile ordering web system.

## Main Rule

Do not invent business rules.

When building or reviewing, follow repository documents first.

Priority:

1. `docs/business-rules/`
2. `docs/google-sheet/`
3. `docs/ui/`
4. `CODEX_INSTRUCTIONS.md`
5. `PROJECT_BRIEF.md`
6. `README.md`

## Product Direction

Build a simple, usable mobile ordering system for a small restaurant.

Core principles:

- Mobile first
- Pickup only
- WhatsApp order submission first
- Google Sheet as low-cost CMS
- No paid API dependency unless approved
- No over-engineered enterprise features
- Clear, fast customer ordering flow
- Easy maintenance for store owner

## Not Allowed Unless Explicitly Requested

Do not add:

- Online payment
- Delivery system
- POS API integration
- Complex membership redemption
- Warehouse / inventory system
- AI recommendation engine
- Paid SaaS dependency
- Over-complicated admin dashboard

## Review Rule

When asked to review the repository:

1. Read all available documentation first.
2. Create or update `docs/codex/FILE_INDEX.md`.
3. Create a written audit report in `docs/codex/`.
4. Clearly separate:
   - Completed
   - Missing
   - Conflicting
   - Risky
   - Next action
5. Do not rewrite the whole project without approval.

## Coding Rule

Before changing code, explain the intended change.

After changing code, report:

- Files changed
- What was completed
- Tests/checks run
- Remaining risks
- Suggested next task

## Validation

Run available checks when possible:

- `npm run lint`
- `npm run typecheck`
- `npm run build`
- Other project-specific tests if documented

If no scripts exist, state that no scripts were available.
